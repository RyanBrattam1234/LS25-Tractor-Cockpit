-- Tractor Cockpit telemetry prototype for FS25.
-- Read-only: no controls or changes to the vehicle are issued.
-- APIs are probed defensively because vehicle implementations can differ.

TractorCockpit = {}
TractorCockpit.MOD_NAME = "TractorCockpit"
TractorCockpit.UPDATE_INTERVAL_MS = 1000
TractorCockpit.elapsedMs = 0
TractorCockpit.lastVehicle = nil

local function safeCall(object, methodName, ...)
    if object == nil then
        return nil
    end

    local method = object[methodName]
    if type(method) ~= "function" then
        return nil
    end

    local ok, a, b, c = pcall(method, object, ...)
    if ok then
        return a, b, c
    end
    return nil
end

local function cleanValue(value)
    if value == nil then
        return "n/a"
    end
    if type(value) == "boolean" then
        return value and "1" or "0"
    end
    if type(value) == "number" then
        if value ~= value or value == math.huge or value == -math.huge then
            return "n/a"
        end
        return string.format("%.2f", value)
    end
    local s = tostring(value)
    s = string.gsub(s, "[|\r\n]", "_")
    return s
end

local function firstAvailable(candidates)
    for _, candidate in ipairs(candidates) do
        local value = candidate()
        if value ~= nil then
            return value
        end
    end
    return nil
end

function TractorCockpit:getControlledVehicle()
    -- In FS25, the local player's current vehicle is the reliable client-side source.
    -- controlledVehicle is kept as a fallback for builds or contexts that expose it.
    if g_localPlayer ~= nil then
        local vehicle = safeCall(g_localPlayer, "getCurrentVehicle")
        if vehicle ~= nil then
            return vehicle
        end
    end

    if g_currentMission ~= nil and g_currentMission.controlledVehicle ~= nil then
        return g_currentMission.controlledVehicle
    end

    return nil
end

function TractorCockpit:getVehicleName(vehicle)
    local name = safeCall(vehicle, "getName")
    if name ~= nil and tostring(name) ~= "" then
        return name
    end
    if vehicle.configFileName ~= nil then
        return vehicle.configFileName
    end
    return "Vehicle"
end

function TractorCockpit:getSpeed(vehicle)
    -- The exact availability/units of these methods must be confirmed in the target build.
    return firstAvailable({
        function() return safeCall(vehicle, "getLastSpeed") end,
        function() return safeCall(vehicle, "getSpeed") end
    })
end

function TractorCockpit:getMotor(vehicle)
    if vehicle.spec_motorized ~= nil and vehicle.spec_motorized.motor ~= nil then
        return vehicle.spec_motorized.motor
    end
    return safeCall(vehicle, "getMotor")
end

function TractorCockpit:getRpm(vehicle)
    local motor = self:getMotor(vehicle)
    return firstAvailable({
        function() return safeCall(vehicle, "getMotorRpm") end,
        function() return safeCall(motor, "getLastMotorRpm") end,
        function() return safeCall(motor, "getMotorRpm") end,
        function()
            if motor ~= nil then
                return motor.lastMotorRpm
            end
            return nil
        end
    })
end

function TractorCockpit:getFuel(vehicle)
    -- FS25 motorized vehicles expose their fuel fill unit through the consumer API.
    if FillType ~= nil then
        local fuelTypes = { FillType.DIESEL, FillType.ELECTRICCHARGE, FillType.METHANE }
        for _, fillType in ipairs(fuelTypes) do
            if fillType ~= nil then
                local index = safeCall(vehicle, "getConsumerFillUnitIndex", fillType)
                if index ~= nil then
                    local level = safeCall(vehicle, "getFillUnitFillLevel", index)
                    local capacity = safeCall(vehicle, "getFillUnitCapacity", index)
                    if level ~= nil then
                        return level, capacity
                    end
                end
            end
        end
    end

    -- Defensive fallback for vehicles/mods with a non-standard consumer setup.
    if vehicle.spec_fillUnit ~= nil and vehicle.spec_fillUnit.fillUnits ~= nil then
        for _, unit in pairs(vehicle.spec_fillUnit.fillUnits) do
            if unit ~= nil and unit.fillLevel ~= nil and unit.fillType ~= nil and FillType ~= nil then
                if unit.fillType == FillType.DIESEL
                    or unit.fillType == FillType.ELECTRICCHARGE
                    or unit.fillType == FillType.METHANE then
                    return unit.fillLevel, unit.capacity
                end
            end
        end
    end
    return nil, nil
end

function TractorCockpit:getEngineState(vehicle)
    -- FS25 exposes this check on the vehicle; keep motor-level fallbacks as well.
    local state = safeCall(vehicle, "getIsMotorStarted")
    local motor = self:getMotor(vehicle)
    if state == nil then
        state = safeCall(motor, "getIsMotorStarted")
    end
    if state == nil and motor ~= nil then
        state = motor.isMotorStarted
    end
    return state
end

function TractorCockpit:getPosition(vehicle)
    if vehicle.rootNode == nil or type(getWorldTranslation) ~= "function" then
        return nil, nil, nil
    end
    local ok, x, y, z = pcall(getWorldTranslation, vehicle.rootNode)
    if ok then
        return x, y, z
    end
    return nil, nil, nil
end

function TractorCockpit:emitTelemetry(vehicle)
    local name = self:getVehicleName(vehicle)
    local speed = self:getSpeed(vehicle)
    local rpm = self:getRpm(vehicle)
    local fuel, fuelCapacity = self:getFuel(vehicle)
    local engine = self:getEngineState(vehicle)
    local x, y, z = self:getPosition(vehicle)

    -- One simple pipe-delimited line per second; Python reads it from log.txt.
    print("TRACTORCOCKPIT|name=" .. cleanValue(name)
        .. "|speed=" .. cleanValue(speed)
        .. "|rpm=" .. cleanValue(rpm)
        .. "|fuel=" .. cleanValue(fuel)
        .. "|fuelCapacity=" .. cleanValue(fuelCapacity)
        .. "|engine=" .. cleanValue(engine)
        .. "|x=" .. cleanValue(x)
        .. "|y=" .. cleanValue(y)
        .. "|z=" .. cleanValue(z))
end

function TractorCockpit:loadMap(name)
    print("TractorCockpit: loaded. Read-only telemetry prototype; no vehicle controls enabled.")
end

function TractorCockpit:deleteMap()
    print("TractorCockpit: map closed.")
end

function TractorCockpit:update(dt)
    self.elapsedMs = self.elapsedMs + dt
    if self.elapsedMs < self.UPDATE_INTERVAL_MS then
        return
    end
    self.elapsedMs = 0

    local vehicle = self:getControlledVehicle()
    if vehicle ~= nil then
        self:emitTelemetry(vehicle)
        self.lastVehicle = vehicle
    else
        -- Keep the backend aware that no controlled vehicle is currently selected.
        print("TRACTORCOCKPIT|name=No vehicle|speed=n/a|rpm=n/a|fuel=n/a|fuelCapacity=n/a|engine=n/a|x=n/a|y=n/a|z=n/a")
        self.lastVehicle = nil
    end
end

addModEventListener(TractorCockpit)
